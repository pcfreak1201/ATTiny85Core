// picoUART print functions
#pragma once

extern "C" void prints(const char* s);
extern "C" void prints_P(const char* s);
